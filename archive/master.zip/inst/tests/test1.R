
test_that("dummy database access", {
  studyName <- "study1"
  studyData <- c(1,2,3,4)
  db <<- list()
  db[[studyName]] <<- studyData

  expect_that(getData("study1"), equals(c(1,2,3,4)))
})