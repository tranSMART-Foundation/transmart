library(testthat)
library(ToyProject)

test_package("ToyProject")